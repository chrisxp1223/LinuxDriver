#ifndef AMD_TEST_INC
#define AMD_TEST_INC
int testNXDisabled(void);
void amd_diagnostics_test(void);
#endif
